export interface Book {
  id: number;
  author: string;
  isbn: string;
  imageUrl: string;
  checkedOut: boolean;
}
